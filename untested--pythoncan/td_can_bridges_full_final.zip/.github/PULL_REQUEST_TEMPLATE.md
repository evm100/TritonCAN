
## 🧾 Summary
<!-- Briefly describe the change -->

## 🔧 Type of Change
- [ ] New feature
- [ ] Bug fix
- [ ] Documentation update

## 🧩 Related Issues
Closes #

## 🧠 Implementation Details
<!-- Explain design decisions -->

## 🧪 Test Plan
- [ ] Hardware tested
- [ ] Unit tests updated

## 🧰 Checklist
- [ ] Formatted
- [ ] Linted
- [ ] Docs updated
