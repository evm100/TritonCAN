
# 🧾 Changelog

## [0.1.0] - Initial Release
- Multi-bus ROS ↔ CAN bridge core
- RS02 motor telemetry DBC & YAML examples
- Interactive registration tool (`td_can_register.py`)
- Modular architecture with per-bus workers
